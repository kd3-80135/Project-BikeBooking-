package com.bike.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BikeBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
