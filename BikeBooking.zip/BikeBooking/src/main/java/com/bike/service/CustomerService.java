package com.bike.service;

public interface CustomerService {
	

}
