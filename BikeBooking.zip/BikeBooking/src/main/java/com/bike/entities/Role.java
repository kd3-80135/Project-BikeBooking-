package com.bike.entities;

public enum Role {
	ADMIN_ROLE, CUSTOMER_ROLE, DEALER_ROLE
}
